# PRODIGY_WD_02
To build a stopwatch web appliaction using html,css,javascript
